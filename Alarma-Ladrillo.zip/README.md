# Alarma Ladrillo (DATCO)

App Android de alarma con tonos ladrillo suaves.

- Alarmas por día, con sonidos suaves que suben de a poco (Amanecer, Pájaros, Lluvia suave, Olas, Caja de música)
- Voz al despertar: día, hora y clima de tu ciudad
- Sueño: horas dormidas y detección de ronquidos
- Cronómetro con vueltas y temporizador
- Splash de DATCO

## Compilar en GitHub
1. Subí todo el contenido de este zip a un repositorio (rama main).
2. Entrá a Actions > "Compilar Alarma Ladrillo" (se ejecuta solo al subir).
3. Al terminar, bajá el artefacto "Alarma-Ladrillo-APK" y abrí app-debug.apk en el celular.
