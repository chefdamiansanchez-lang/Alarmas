package com.datco.alarmaladrillo

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

data class Night(val start: Long, val end: Long, val snores: List<Long>)

object SleepStore {
    private const val PREFS = "sueno"

    private fun p(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun parseLongs(raw: String): List<Long> {
        val out = ArrayList<Long>()
        try {
            val a = JSONArray(raw)
            for (i in 0 until a.length()) out.add(a.getLong(i))
        } catch (e: Exception) {
        }
        return out
    }

    @Synchronized
    fun activeStart(ctx: Context): Long = p(ctx).getLong("start", 0L)

    @Synchronized
    fun begin(ctx: Context) {
        p(ctx).edit().putLong("start", System.currentTimeMillis()).putString("snores", "[]").apply()
    }

    @Synchronized
    fun activeSnores(ctx: Context): List<Long> = parseLongs(p(ctx).getString("snores", "[]") ?: "[]")

    @Synchronized
    fun addSnore(ctx: Context, t: Long) {
        val l = activeSnores(ctx).toMutableList()
        l.add(t)
        val arr = JSONArray()
        for (x in l) arr.put(x)
        p(ctx).edit().putString("snores", arr.toString()).apply()
    }

    @Synchronized
    fun history(ctx: Context): List<Night> {
        val out = ArrayList<Night>()
        try {
            val arr = JSONArray(p(ctx).getString("history", "[]") ?: "[]")
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                out.add(Night(o.getLong("s"), o.getLong("e"), parseLongs(o.getJSONArray("n").toString())))
            }
        } catch (e: Exception) {
        }
        return out
    }

    @Synchronized
    fun end(ctx: Context): Night? {
        val s = activeStart(ctx)
        if (s == 0L) return null
        val night = Night(s, System.currentTimeMillis(), activeSnores(ctx))
        p(ctx).edit().putLong("start", 0L).putString("snores", "[]").apply()
        // sesiones de menos de 5 minutos no se guardan
        if (night.end - night.start < 5 * 60 * 1000L) return night
        val h = history(ctx).toMutableList()
        h.add(0, night)
        while (h.size > 30) h.removeAt(h.size - 1)
        val arr = JSONArray()
        for (n in h) {
            val o = JSONObject()
            o.put("s", n.start)
            o.put("e", n.end)
            val na = JSONArray()
            for (x in n.snores) na.put(x)
            o.put("n", na)
            arr.put(o)
        }
        p(ctx).edit().putString("history", arr.toString()).apply()
        return night
    }

    fun sensitivity(ctx: Context): Int = p(ctx).getInt("sens", 1)

    fun setSensitivity(ctx: Context, v: Int) {
        p(ctx).edit().putInt("sens", v).apply()
    }
}

class SleepService : Service() {

    companion object {
        const val CHANNEL = "sueno_registro"
        const val NOTIF_ID = 4022

        @Volatile
        var running = false

        fun start(ctx: Context) {
            if (SleepStore.activeStart(ctx) == 0L) SleepStore.begin(ctx)
            ContextCompat.startForegroundService(ctx, Intent(ctx, SleepService::class.java))
        }

        fun end(ctx: Context): Night? {
            ctx.stopService(Intent(ctx, SleepService::class.java))
            return SleepStore.end(ctx)
        }
    }

    private var thread: Thread? = null
    private var wake: PowerManager.WakeLock? = null

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (running) return START_NOT_STICKY
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CHANNEL, "Registro de sueño", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(
            this, 3, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n: Notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(R.drawable.ic_stat_alarm)
            .setContentTitle("Registrando tu sueño")
            .setContentText("Escuchando ronquidos")
            .setOngoing(true)
            .setContentIntent(open)
            .build()
        try {
            ServiceCompat.startForeground(this, NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } catch (e: Exception) {
            stopSelf()
            return START_NOT_STICKY
        }
        running = true
        try {
            val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
            wake = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "alarmaladrillo:sueno")
            wake?.acquire(12 * 60 * 60 * 1000L)
        } catch (e: Exception) {
        }
        thread = Thread { listen() }.also { it.start() }
        return START_NOT_STICKY
    }

    private fun threshold(): Double = when (SleepStore.sensitivity(this)) {
        0 -> 0.03
        2 -> 0.012
        else -> 0.02
    }

    private fun listen() {
        val rate = 16000
        val minBuf = AudioRecord.getMinBufferSize(rate, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
        if (minBuf <= 0) return
        val rec: AudioRecord = try {
            AudioRecord(
                MediaRecorder.AudioSource.MIC, rate,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                maxOf(minBuf, rate)
            )
        } catch (e: Exception) {
            return
        }
        if (rec.state != AudioRecord.STATE_INITIALIZED) {
            rec.release()
            return
        }
        try {
            rec.startRecording()
        } catch (e: Exception) {
            rec.release()
            return
        }

        val buf = ShortArray(rate / 10)
        var floor = 0.01
        var loud = false
        var loudStart = 0L
        val series = ArrayList<Long>()

        while (running) {
            val n = rec.read(buf, 0, buf.size)
            if (n <= 0) {
                try {
                    Thread.sleep(100)
                } catch (e: InterruptedException) {
                }
                continue
            }
            var sum = 0.0
            for (i in 0 until n) {
                val v = buf[i] / 32768.0
                sum += v * v
            }
            val rms = Math.sqrt(sum / n)
            val now = System.currentTimeMillis()
            floor = if (rms < floor) maxOf(rms, 0.001) else floor + (rms - floor) * 0.002
            val thr = maxOf(floor * 3.0, threshold())

            if (!loud && rms > thr) {
                loud = true
                loudStart = now
            } else if (loud && rms < thr * 0.7) {
                loud = false
                val d = now - loudStart
                if (d in 300L..3000L) {
                    // ronquido = ruidos rítmicos, uno cada 1,5 a 9 segundos
                    if (series.isNotEmpty() && (now - series.last()) !in 1500L..9000L) series.clear()
                    series.add(now)
                    if (series.size == 3) {
                        for (t in series) SleepStore.addSnore(this, t)
                    } else if (series.size > 3) {
                        SleepStore.addSnore(this, now)
                    }
                    if (series.size > 50) series.removeAt(0)
                }
            }
            if (loud && now - loudStart > 6000L) loud = false
        }
        try {
            rec.stop()
        } catch (e: Exception) {
        }
        rec.release()
    }

    override fun onDestroy() {
        running = false
        try {
            if (wake?.isHeld == true) wake?.release()
        } catch (e: Exception) {
        }
        super.onDestroy()
    }
}
