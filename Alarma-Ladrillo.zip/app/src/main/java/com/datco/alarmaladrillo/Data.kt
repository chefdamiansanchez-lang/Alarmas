package com.datco.alarmaladrillo

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

data class Alarm(
    val id: Int,
    val hour: Int,
    val minute: Int,
    val days: Set<Int>,
    val enabled: Boolean,
    val sound: Int,
    val label: String
)

object AlarmStore {
    private const val PREFS = "alarmas"
    private const val KEY = "lista"

    fun load(ctx: Context): List<Alarm> {
        val raw = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val out = ArrayList<Alarm>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val d = HashSet<Int>()
                val da = o.optJSONArray("days")
                if (da != null) {
                    for (j in 0 until da.length()) d.add(da.getInt(j))
                }
                out.add(
                    Alarm(
                        o.getInt("id"), o.getInt("h"), o.getInt("m"), d,
                        o.optBoolean("on", true), o.optInt("s", 0), o.optString("l", "")
                    )
                )
            }
        } catch (e: Exception) {
            // lista dañada: se ignora
        }
        return out
    }

    fun save(ctx: Context, list: List<Alarm>) {
        val arr = JSONArray()
        for (a in list) {
            val o = JSONObject()
            o.put("id", a.id)
            o.put("h", a.hour)
            o.put("m", a.minute)
            val da = JSONArray()
            for (d in a.days) da.put(d)
            o.put("days", da)
            o.put("on", a.enabled)
            o.put("s", a.sound)
            o.put("l", a.label)
            arr.put(o)
        }
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, arr.toString()).apply()
    }

    fun nextId(list: List<Alarm>): Int = (list.maxOfOrNull { it.id } ?: 0) + 1

    fun nextTrigger(a: Alarm, from: Long = System.currentTimeMillis()): Long {
        for (offset in 0..7) {
            val c = Calendar.getInstance()
            c.timeInMillis = from
            c.add(Calendar.DAY_OF_YEAR, offset)
            c.set(Calendar.HOUR_OF_DAY, a.hour)
            c.set(Calendar.MINUTE, a.minute)
            c.set(Calendar.SECOND, 0)
            c.set(Calendar.MILLISECOND, 0)
            if (c.timeInMillis <= from) continue
            if (a.days.isEmpty() || a.days.contains(c.get(Calendar.DAY_OF_WEEK))) return c.timeInMillis
        }
        return from + 24L * 60L * 60L * 1000L
    }

    fun restante(a: Alarm): String {
        val diff = nextTrigger(a) - System.currentTimeMillis()
        val min = (diff + 59_999L) / 60_000L
        val h = min / 60
        val m = min % 60
        return if (h > 0) "$h h $m min" else "$m min"
    }
}

object Scheduler {
    const val EXTRA_ID = "alarm_id"
    const val EXTRA_TYPE = "type"
    const val EXTRA_SOUND = "sound"
    const val EXTRA_LABEL = "label"
    const val TIMER_SOUND = 4
    private const val REQ_TIMER = 100000
    private const val REQ_SNOOZE = 100001

    private fun pi(ctx: Context, code: Int, intent: Intent): PendingIntent =
        PendingIntent.getBroadcast(ctx, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

    private fun setClock(ctx: Context, at: Long, op: PendingIntent) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val show = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.setAlarmClock(AlarmManager.AlarmClockInfo(at, show), op)
    }

    private fun cancelCode(ctx: Context, code: Int) {
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        am.cancel(pi(ctx, code, Intent(ctx, AlarmReceiver::class.java)))
    }

    fun schedule(ctx: Context, a: Alarm) {
        cancelCode(ctx, a.id)
        if (!a.enabled) return
        val intent = Intent(ctx, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ID, a.id)
            putExtra(EXTRA_TYPE, "alarm")
            putExtra(EXTRA_SOUND, a.sound)
            putExtra(EXTRA_LABEL, a.label)
        }
        setClock(ctx, AlarmStore.nextTrigger(a), pi(ctx, a.id, intent))
    }

    fun cancel(ctx: Context, id: Int) = cancelCode(ctx, id)

    fun rescheduleAll(ctx: Context) {
        for (a in AlarmStore.load(ctx)) schedule(ctx, a)
    }

    fun scheduleTimer(ctx: Context, at: Long) {
        val intent = Intent(ctx, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ID, -1)
            putExtra(EXTRA_TYPE, "timer")
            putExtra(EXTRA_SOUND, TIMER_SOUND)
            putExtra(EXTRA_LABEL, "")
        }
        setClock(ctx, at, pi(ctx, REQ_TIMER, intent))
    }

    fun cancelTimer(ctx: Context) = cancelCode(ctx, REQ_TIMER)

    fun snooze(ctx: Context, minutes: Int, sound: Int, label: String) {
        val intent = Intent(ctx, AlarmReceiver::class.java).apply {
            putExtra(EXTRA_ID, -1)
            putExtra(EXTRA_TYPE, "snooze")
            putExtra(EXTRA_SOUND, sound)
            putExtra(EXTRA_LABEL, label)
        }
        setClock(ctx, System.currentTimeMillis() + minutes * 60_000L, pi(ctx, REQ_SNOOZE, intent))
    }
}

object TimerStore {
    private const val PREFS = "temporizador"

    fun end(ctx: Context): Long = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getLong("end", 0L)

    fun start(ctx: Context, ms: Long) {
        val at = System.currentTimeMillis() + ms
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong("end", at).apply()
        Scheduler.scheduleTimer(ctx, at)
    }

    fun clear(ctx: Context) {
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putLong("end", 0L).apply()
        Scheduler.cancelTimer(ctx)
    }
}

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val type = intent.getStringExtra(Scheduler.EXTRA_TYPE) ?: "alarm"
        val id = intent.getIntExtra(Scheduler.EXTRA_ID, -1)
        if (type == "alarm") {
            val list = AlarmStore.load(ctx)
            val a = list.firstOrNull { it.id == id }
            if (a != null) {
                if (a.days.isEmpty()) {
                    AlarmStore.save(ctx, list.map { if (it.id == id) it.copy(enabled = false) else it })
                } else {
                    Scheduler.schedule(ctx, a)
                }
            }
        }
        val svc = Intent(ctx, AlarmService::class.java)
        svc.putExtras(intent)
        try {
            ContextCompat.startForegroundService(ctx, svc)
        } catch (e: Exception) {
            // sin permiso para iniciar el servicio
        }
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        Scheduler.rescheduleAll(ctx)
    }
}
