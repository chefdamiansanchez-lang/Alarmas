package com.datco.alarmaladrillo

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationManager
import android.os.Build
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class WeatherInfo(val city: String, val temp: Int, val desc: String, val code: Int)

object Weather {
    private const val PREFS = "clima"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun cached(ctx: Context): WeatherInfo? {
        val p = prefs(ctx)
        val city = p.getString("city", null) ?: return null
        if (!p.contains("temp")) return null
        return WeatherInfo(city, p.getInt("temp", 0), p.getString("desc", "") ?: "", p.getInt("code", 0))
    }

    private fun hasPermission(ctx: Context): Boolean {
        val fine = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val coarse = ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
        return fine || coarse
    }

    private fun saveLoc(ctx: Context, loc: Location) {
        prefs(ctx).edit()
            .putString("lat", loc.latitude.toString())
            .putString("lon", loc.longitude.toString())
            .apply()
    }

    @SuppressLint("MissingPermission")
    private fun lastKnown(ctx: Context): Location? {
        if (!hasPermission(ctx)) return null
        val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        var best: Location? = null
        for (provider in lm.getProviders(true)) {
            val l = try {
                lm.getLastKnownLocation(provider)
            } catch (e: Exception) {
                null
            }
            if (l == null) continue
            val b = best
            if (b == null || l.time > b.time) best = l
        }
        return best
    }

    /** Pide una ubicación nueva (Android 11 o superior). Siempre llama a done(). */
    @SuppressLint("MissingPermission")
    fun requestFresh(ctx: Context, done: () -> Unit) {
        if (Build.VERSION.SDK_INT >= 30 && hasPermission(ctx)) {
            try {
                val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
                val provider = when {
                    lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
                    lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
                    else -> null
                }
                if (provider != null) {
                    lm.getCurrentLocation(provider, null, ContextCompat.getMainExecutor(ctx)) { loc: Location? ->
                        if (loc != null) saveLoc(ctx, loc)
                        done()
                    }
                    return
                }
            } catch (e: Exception) {
                // se usa la última ubicación conocida
            }
        }
        done()
    }

    private fun cityName(ctx: Context, lat: Double, lon: Double): String? {
        return try {
            if (!Geocoder.isPresent()) return null
            val list = Geocoder(ctx, Locale("es")).getFromLocation(lat, lon, 1)
            val a = list?.firstOrNull() ?: return null
            a.locality ?: a.subAdminArea ?: a.adminArea
        } catch (e: Exception) {
            null
        }
    }

    /** Bloqueante: llamar desde un hilo secundario. */
    fun fetch(ctx: Context): WeatherInfo? {
        val p = prefs(ctx)
        val loc = lastKnown(ctx)
        if (loc != null) saveLoc(ctx, loc)
        val lat = p.getString("lat", null)?.toDoubleOrNull()
        val lon = p.getString("lon", null)?.toDoubleOrNull()
        if (lat == null || lon == null) return cached(ctx)
        return try {
            val url = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto")
            val conn = url.openConnection() as HttpURLConnection
            conn.connectTimeout = 5000
            conn.readTimeout = 5000
            val txt = conn.inputStream.bufferedReader().use { it.readText() }
            conn.disconnect()
            val cur = JSONObject(txt).getJSONObject("current")
            val temp = Math.round(cur.getDouble("temperature_2m")).toInt()
            val code = cur.getInt("weather_code")
            val city = cityName(ctx, lat, lon) ?: p.getString("city", null) ?: "tu ubicación"
            val info = WeatherInfo(city, temp, describe(code), code)
            p.edit()
                .putString("city", info.city)
                .putInt("temp", info.temp)
                .putString("desc", info.desc)
                .putInt("code", info.code)
                .apply()
            info
        } catch (e: Exception) {
            cached(ctx)
        }
    }

    fun describe(code: Int): String = when (code) {
        0 -> "cielo despejado"
        1 -> "mayormente despejado"
        2 -> "parcialmente nublado"
        3 -> "nublado"
        45, 48 -> "con niebla"
        in 51..55 -> "llovizna"
        56, 57 -> "llovizna helada"
        61 -> "lluvia débil"
        63 -> "lluvia moderada"
        65 -> "lluvia fuerte"
        66, 67 -> "lluvia helada"
        in 71..75 -> "nevada"
        77 -> "granizo fino"
        in 80..82 -> "chaparrones"
        85, 86 -> "nevadas"
        95 -> "tormenta"
        96, 99 -> "tormenta con granizo"
        else -> "clima variable"
    }

    fun emoji(code: Int): String = when (code) {
        0 -> "☀️"
        1, 2 -> "🌤️"
        3 -> "☁️"
        45, 48 -> "🌫️"
        in 51..57 -> "🌦️"
        in 61..67 -> "🌧️"
        in 71..77 -> "❄️"
        in 80..82 -> "🌧️"
        85, 86 -> "❄️"
        95, 96, 99 -> "⛈️"
        else -> "🌡️"
    }
}
